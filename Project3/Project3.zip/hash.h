#ifndef HASH_H 
#define HASH_H

typedef struct node
{
   HTEntry E;
   HTMetrics M;
   struct node *next;
} linkedList;

typedef struct
{
   linkedList **nodes;
   unsigned *csizes;
   unsigned *chains;
   int index;
   HTFunctions *functions;
   float loadFac;
   int numS;
   unsigned unique;
   unsigned total;
} Htable; 

linkedList* addHead(linkedList *list, HTEntry e);
unsigned checkRepeat(Htable *h, linkedList *current, void *data);
int needRehash(Htable *h);
void rehash(Htable *h);
unsigned findMaxChain(Htable *h);

#endif
