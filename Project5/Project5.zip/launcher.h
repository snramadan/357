#ifndef LAUNCHER_H
#define LAUNCHER_H

void errorMsg();
void usError();
void arguments(char *a[], int *c, int *p, int *i);

#endif
