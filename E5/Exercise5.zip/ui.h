#include "cuboid.h"

#ifndef UI_H
   #define UI_H

   double getLength();
   double getWidth();
   double getHeight();
   void showResults(Cuboid c);

#endif
